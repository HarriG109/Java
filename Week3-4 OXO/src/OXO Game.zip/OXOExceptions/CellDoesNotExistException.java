package OXOExceptions;

public class CellDoesNotExistException extends OXOMoveException
{
    public CellDoesNotExistException(){

    }

    public String toString(){
        return "Cell does not exist: ";
    }
}
